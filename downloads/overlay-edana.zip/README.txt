﻿This is a standalone OBS Browser Source overlay for Enhancement Tracker.

SETUP
1. Unzip this folder anywhere on your PC (keep all the files together).
2. Put a copy of your enhancement-tracker.json save file in this same folder.
   - If you use the tracker's "Link Save File" feature, point it at this folder and it will
     keep writing to the same file automatically.
   - Otherwise, use the tracker's Export button whenever you want the overlay to catch up.
3. In OBS: Add Source -> Browser -> Local File, and select the overlay's .html file here.

The overlay re-reads enhancement-tracker.json every few seconds on its own -- no manual
refresh needed. It only ever reads that file; it never writes to it or sends it anywhere.

OPTIONAL URL PARAMETERS (append to the file path in OBS), e.g.:
  overlay-ekleta.html?interval=2000&bg=0.85

  interval=<ms>   poll rate, default 3000
  bg=<0-1>        panel background opacity
  items=id1,id2   show only specific piece ids
  stats=0         hide the stats row
  levels=0        hide the per-level rate breakdown
  file=<name>     use a different JSON filename/path than the default

ASSET NOTICE
The icon artwork included in the Images/ folder here depicts in-game items from Black Desert
Online, (c) Pearl Abyss Corp. Some icons were sourced via bdocodex.com. This is an unofficial,
non-commercial fan-made tool; no ownership of this artwork is claimed, and it is not affiliated
with or endorsed by Pearl Abyss.
